Headless Ninja Volley v0.9
by Haroldo O. Pinheiro
haroldoop@gmail.com

The premise of the game is pretty simple:

At the beginning, the game will show a menu where you can choose whether you'll play against a friend or against the computer, as well as the color palette. Use arrows to select, and any button to start the game.

Once inside the actual game, left and right arrows move your ninja, while any button jumps. You can do an off-wall jump, too, by pressing jump while moving against a wall.

Try to push the ball to the opponent's field, while trying to stop it from bouncing twice on your side. The game ends when someone scores 15 points.

This is the 0.05 alpha version of the Genesis RPG Creator.
Being an incomplete alpha version, there's still many bugs and many unimplemented features.

The current version will support only a single map (whose ID must be "MAPTEST") and a single tileset (whose ID must be "TESTE"). There's neither character placement, nor script compiler yet. All the unimplemented features shall be implemented on future versions.

To create a working ROM, simply open the included example project file (Teste.gpr), click on Compile->Compile, type the name of the ROM you want to generate (it must have the .BIN extension), and then click on save. Then you may open the resulting ROM on your favorite Sega Genesis/MegaDrive emulator.

Future updates will be on my homepage: http://members.fortunecity.com/haroldoop
You may e-mail me at haroldoop@gmail.com
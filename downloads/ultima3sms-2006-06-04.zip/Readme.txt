This is an pre-alpha version of a port of Ultima 3 from PC to the Sega Master System.
This is still in the initial stages, but you can already view some of the maps.
Use the directional to scroll around the map.
Use the PAUSE button to alternate between the main Sosaria map and Lord British's castle.
Place your character over a NPC an press button 1 to hear what he/she has to say (Of course, this just for testing).